import java.util.regex.Pattern;

public class JWTGuardrail {

    public static void main(String[] args) {

        System.out.println("=== Project 4 - JWT Output Guardrail ===");
        System.out.println();

        String response =
                "Model response: eyJhbGciOiJIUzI1NiJ9.TEST.PAYLOAD";

        System.out.println("Original model response:");
        System.out.println(response);
        System.out.println();

        Pattern jwtPattern =
                Pattern.compile("eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+");

        String redacted =
                jwtPattern.matcher(response).replaceAll("[REDACTED]");

        if (!response.equals(redacted)) {
            System.out.println("Guardrail output:");
            System.out.println(redacted);
            System.out.println();
            System.out.println("Status: BLOCKED");
            System.out.println("Reason: JWT-shaped credential redacted");
        } else {
            System.out.println("Status: ALLOWED");
        }
    }
}