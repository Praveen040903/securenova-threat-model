import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;

public class MessageVerification {

    public static void main(String[] args) throws Exception {

        System.out.println("=== Project 4 - Agent Identity Verification ===");
        System.out.println();

        KeyPairGenerator generator =
                KeyPairGenerator.getInstance("Ed25519");

        KeyPair keyPair = generator.generateKeyPair();

        String originalMessage =
                "Agent B: Execute approved task";

        System.out.println("Original message:");
        System.out.println(originalMessage);
        System.out.println();

        Signature signer = Signature.getInstance("Ed25519");

        signer.initSign(keyPair.getPrivate());
        signer.update(originalMessage.getBytes(StandardCharsets.UTF_8));

        byte[] signature = signer.sign();

        System.out.println("Signature created: SUCCESS");
        System.out.println();

        String tamperedMessage =
                "Agent B: Execute privileged task";

        System.out.println("Tampered message:");
        System.out.println(tamperedMessage);
        System.out.println();

        Signature verifier =
                Signature.getInstance("Ed25519");

        verifier.initVerify(keyPair.getPublic());
        verifier.update(
                tamperedMessage.getBytes(StandardCharsets.UTF_8)
        );

        boolean valid = verifier.verify(signature);

        if (!valid) {
            System.out.println("Status: REJECTED");
            System.out.println(
                    "Reason: Signature verification failed - message was tampered"
            );
        } else {
            System.out.println("Status: ACCEPTED");
        }
    }
}