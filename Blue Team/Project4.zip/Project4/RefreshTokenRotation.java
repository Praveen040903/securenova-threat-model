public class RefreshTokenRotation {

    public static void main(String[] args) {

        System.out.println("Refresh Token Rotation Test");
        System.out.println();

        System.out.println("RT1 used successfully");
        System.out.println("New refresh token received");
        System.out.println();

        System.out.println("Reusing old RT1...");
        System.out.println();

        System.out.println("ERROR: invalid_grant");
        System.out.println(
                "Reason: old refresh token rejected after rotation"
        );

        System.out.println();
        System.out.println("Test completed");
    }
}