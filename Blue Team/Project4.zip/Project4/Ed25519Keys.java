import java.security.KeyPair;
import java.security.KeyPairGenerator;

public class Ed25519Keys {

    public static void main(String[] args) throws Exception {

        System.out.println("=== Project 4 - Ed25519 Key Generation ===");
        System.out.println();

        KeyPairGenerator generator =
                KeyPairGenerator.getInstance("Ed25519");

        KeyPair keyPair = generator.generateKeyPair();

        System.out.println("Ed25519 key pair generated successfully.");
        System.out.println();

        System.out.println("Private key generated: YES");
        System.out.println("Public key generated: YES");
        System.out.println();

        System.out.println("Algorithm: " +
                keyPair.getPrivate().getAlgorithm());

        System.out.println("Status: SUCCESS");
    }
}