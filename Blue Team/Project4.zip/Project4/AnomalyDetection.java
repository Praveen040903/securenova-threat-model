import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SS7_AnomalyDetection {

    public static void main(String[] args) {

        System.out.println("=== Project 4 - Anomaly Detection ===");
        System.out.println();
        System.out.println("Testing request-volume spike...");
        System.out.println();

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        String timestamp =
                LocalDateTime.now().format(formatter);

        // Simulate increasing request volume
        for (int requests = 21; requests <= 25; requests++) {

            if (requests > 20) {

                System.out.println("==============================================");
                System.out.println("ANOMALY DETECTED");
                System.out.println("Event Type : API/JLM Request Volume Spike");
                System.out.println("Identity   : SecureNova-Agent");
                System.out.println("Requests   : " + requests);
                System.out.println("Window     : 60 seconds");
                System.out.println("Timestamp  : " + timestamp);
                System.out.println("Alert      : More than 20 requests");
                System.out.println("==============================================");
                System.out.println();
            }
        }

        System.out.println("Anomaly detection test completed.");
    }
}